import React from 'react-native'

const reportSlice = () => {
  return (
    <div>reportSlice</div>
  )
}

export default reportSlice